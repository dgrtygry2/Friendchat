import subprocess
import tkinter as tk
from PIL import Image, ImageTk

def show_loader():
    # Create a tkinter window
    root = tk.Tk()
    root.attributes('-fullscreen', True)  # Set the window to fullscreen
    root.bind("<Escape>", lambda e: root.quit())  # Bind Escape key to exit fullscreen

    # Load the image
    img = Image.open('loader.bmp')
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()

    # Resize the image while maintaining the aspect ratio
    img.thumbnail((screen_width, screen_height))  # Removed Image.ANTIALIAS
    img = ImageTk.PhotoImage(img)

    # Create a label to display the image
    label = tk.Label(root, image=img)
    label.image = img  # Keep a reference to avoid garbage collection
    label.pack(expand=True)

    # Start the chat process
    root.after(0, start_chat)
    root.mainloop()

def start_chat():
    # Execute the "chat.exe"
    subprocess.Popen(['chat.exe'])
    check_chat()  # Start checking for chat.exe

def check_chat():
    # Check if chat.exe is still running
    try:
        # Check the running processes
        chat_process = subprocess.check_output('tasklist', shell=True).decode()
        if 'chat.exe' in chat_process:
            root.after(1000, check_chat)  # Check again in 1 second
        else:
            root.quit()  # Close the tkinter window if chat.exe is not running
    except Exception as e:
        print(f"Error checking process: {e}")
        root.quit()

# Start the loader
show_loader()