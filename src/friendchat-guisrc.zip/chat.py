import tkinter as tk
from transformers import MarianMTModel, MarianTokenizer
import random
import os
import json

# Load the pretrained translation model and tokenizer
model_name = 'Helsinki-NLP/opus-mt-en-zh'
tokenizer_en_zh = MarianTokenizer.from_pretrained(model_name)
model_en_zh = MarianMTModel.from_pretrained(model_name)

model_name_zh_en = 'Helsinki-NLP/opus-mt-zh-en'
tokenizer_zh_en = MarianTokenizer.from_pretrained(model_name_zh_en)
model_zh_en = MarianMTModel.from_pretrained(model_name_zh_en)

# Pool of common Chinese characters for random selection
chinese_characters = list("的一是不了人我在有他这为之大来以个中上们到说国和地也子时道年得就那要下生会自着")

# Create a mapping for English letters to Chinese characters
letter_to_chinese = {
    'a': '阿', 'b': '比', 'c': '次', 'd': '的', 'e': '额', 'f': '非', 'g': '哥', 'h': '哈', 
    'i': '艾', 'j': '杰', 'k': '开', 'l': '了', 'm': '马', 'n': '那', 'o': '哦', 'p': '皮', 
    'q': '求', 'r': '尔', 's': '是', 't': '特', 'u': '乌', 'v': '维', 'w': '维', 'x': '西', 
    'y': '伊', 'z': '兹', 
    'A': '阿', 'B': '比', 'C': '次', 'D': '的', 'E': '额', 'F': '非', 'G': '哥', 'H': '哈', 
    'I': '艾', 'J': '杰', 'K': '开', 'L': '了', 'M': '马', 'N': '那', 'O': '哦', 'P': '皮', 
    'Q': '求', 'R': '尔', 'S': '是', 'T': '特', 'U': '乌', 'V': '维', 'W': '维', 'X': '西', 
    'Y': '伊', 'Z': '兹'
}

# Function to save conversation in Chinese to data.txt
def save_to_data(txt):
    if os.path.exists("data.txt") and os.path.getsize("data.txt") >= 3 * 1024**3:  # 3GB in bytes
        print("Data file size limit reached. Stopping saves.")
        return False  # Stop saving if file size exceeds 3GB
    with open("data.txt", "a", encoding="utf-8") as file:
        file.write(txt + "\n")
    return True

# Function to translate English to Chinese (using the offline model)
def translate_to_chinese(text):
    inputs = tokenizer_en_zh(text, return_tensors="pt", max_length=512, truncation=True)
    translated_tokens = model_en_zh.generate(**inputs)
    translated_text = tokenizer_en_zh.decode(translated_tokens[0], skip_special_tokens=True)
    return translated_text

# Function to translate Chinese to English (using the offline model)
def translate_to_english(text):
    inputs = tokenizer_zh_en(text, return_tensors="pt", max_length=512, truncation=True)
    translated_tokens = model_zh_en.generate(**inputs)
    translated_text = tokenizer_zh_en.decode(translated_tokens[0], skip_special_tokens=True)
    return translated_text

# Markov Chain class for generating sentences
class MarkovChain:
    def __init__(self):
        self.data = self.load_data()
        self.personalities = []
        self.current_personality = None

    def load_data(self):
        """Load Chinese data from the data.txt file."""
        if not os.path.exists("data.txt"):
            return []
        with open("data.txt", "r", encoding="utf-8") as file:
            content = file.read()
        return content.splitlines()

    def generate_sentence(self):
        """Generate a random sentence using the character pool."""
        sentence_length = random.randint(5, 10)  # Random sentence length between 5 and 10 characters
        sentence = ''.join(random.choice(chinese_characters) for _ in range(sentence_length))
        return sentence

    def generate_text(self):
        """Generate 1-2 random sentences."""
        num_sentences = random.randint(1, 2)  # Randomly decide to generate 1 or 2 sentences
        return '。'.join(self.generate_sentence() for _ in range(num_sentences)) + "。"

    def create_personality(self):
        """Generate a new personality for the bot."""
        personality_name = f"Personality {len(self.personalities) + 1}"
        self.personalities.append(personality_name)
        self.current_personality = personality_name
        return personality_name

    def switch_personality(self, index):
        """Switch to a different personality."""
        if 0 <= index < len(self.personalities):
            self.current_personality = self.personalities[index]
            return f"Switched to {self.current_personality}."
        return "Invalid personality index."

    def save_personalities(self):
        """Save current personalities to a file."""
        with open("personalities.json", "w", encoding="utf-8") as f:
            json.dump({"personalities": self.personalities, "current": self.current_personality}, f)

    def load_personalities(self):
        """Load personalities from a file."""
        if os.path.exists("personalities.json"):
            with open("personalities.json", "r", encoding="utf-8") as f:
                data = json.load(f)
                self.personalities = data.get("personalities", [])
                self.current_personality = data.get("current", None)

# Create a Markov Chain object
markov = MarkovChain()

# Load personalities on startup
markov.load_personalities()

# Function to convert each letter of the user input to a Chinese character
def convert_letters_to_chinese(input_text):
    return ''.join(letter_to_chinese.get(char, char) for char in input_text)

# Function to log bot's thoughts if --think mode is activated
def log_thoughts(thought):
    with open("diary.txt", "a", encoding="utf-8") as diary_file:
        # Limit diary entry length
        if len(thought) <= 500:  # Set limit to 500 characters
            diary_file.write(thought + "\n")
        else:
            diary_file.write(thought[:500] + "...(truncated)\n")

# Function to handle bot response generation
def generate_bot_response(user_input):
    # Convert each letter in user input to Chinese character
    converted_input = convert_letters_to_chinese(user_input)

    # Try to save converted input to data.txt
    if save_to_data(converted_input):
        print("User input saved.")

    responses = []

    # Check the modes and generate responses accordingly
    # Generate a personalized thought
    if think_var.get():
        thoughts = f"Bot is thinking about: {user_input}."
        log_thoughts(thoughts)  # Log thoughts to diary.txt
        responses.append(thoughts)

    # Create mode
    if create_var.get():
        personality = markov.create_personality()
        responses.append(f"New personality created: {personality}")

    # RP mode
    if rp_var.get():
        random_response = markov.generate_text()
        translated_response = translate_to_english(random_response)  # Translate the RP response
        responses.append(f"[RP] {translated_response}")

    # Diary mode
    if d_var.get():
        diary_entry = f"Diary entry: {user_input}"
        log_thoughts(diary_entry)  # Write diary entry
        responses.append("Diary entry added.")

    # Generate a response using random Chinese sentences
    chinese_response = markov.generate_text()

    # Translate the bot's Chinese response back to English
    english_response = translate_to_english(chinese_response)

    responses.append(english_response)

    # Personality context
    if markov.current_personality:
        responses.append(f"[{markov.current_personality}] " + english_response)

    return "\n".join(responses)

# Function to handle user input and bot response
def handle_user_input():
    user_input = entry.get()

    if user_input.strip():
        # Display user input in the chat window
        chatbox.config(state=tk.NORMAL)
        chatbox.insert(tk.END, f"User: {user_input}\n")
        chatbox.config(state=tk.DISABLED)

        # Generate bot response
        bot_response = generate_bot_response(user_input)

        # Display bot response in the chat window
        chatbox.config(state=tk.NORMAL)
        chatbox.insert(tk.END, f"Bot: {bot_response}\n")
        chatbox.config(state=tk.DISABLED)

        # Clear user input field
        entry.delete(0, tk.END)

# Function to handle mode changes
def handle_mode_change():
    # Get the state of the checkboxes and respond immediately
    if think_var.get():
        chatbox.insert(tk.END, "Bot is now in --think mode.\n")
    if create_var.get():
        chatbox.insert(tk.END, "Bot is now in --create mode.\n")
    if rp_var.get():
        chatbox.insert(tk.END, "Bot is now in --rp mode.\n")
    if d_var.get():
        chatbox.insert(tk.END, "Diary mode activated.\n")

# Function to view diary entries
def view_diary_entries():
    if os.path.exists("diary.txt"):
        with open("diary.txt", "r", encoding="utf-8") as diary_file:
            diary_content = diary_file.read()
            diary_window = tk.Toplevel(window)
            diary_window.title("Diary Entries")
            diary_text = tk.Text(diary_window, height=15, width=50)
            diary_text.insert(tk.END, diary_content)
            diary_text.config(state=tk.DISABLED)  # Make it read-only
            diary_text.pack()
    else:
        print("No diary entries found.")

# Create main window
window = tk.Tk()
window.title("Chatbot")

# Creating a chatbox to display conversation
chatbox = tk.Text(window, height=15, width=50, state=tk.DISABLED)
chatbox.pack()

# Creating an entry box for user input
entry = tk.Entry(window, width=50)
entry.pack()

# Create a send button
send_button = tk.Button(window, text="Send", command=handle_user_input)
send_button.pack()

# Checkbuttons for different modes
think_var = tk.BooleanVar()
create_var = tk.BooleanVar()
rp_var = tk.BooleanVar()
d_var = tk.BooleanVar()

think_checkbox = tk.Checkbutton(window, text="--think", variable=think_var, command=handle_mode_change)
think_checkbox.pack(anchor=tk.W)

create_checkbox = tk.Checkbutton(window, text="--create", variable=create_var, command=handle_mode_change)
create_checkbox.pack(anchor=tk.W)

rp_checkbox = tk.Checkbutton(window, text="--rp", variable=rp_var, command=handle_mode_change)
rp_checkbox.pack(anchor=tk.W)

d_checkbox = tk.Checkbutton(window, text="--d", variable=d_var, command=handle_mode_change)
d_checkbox.pack(anchor=tk.W)

# Button to view diary entries
view_diary_button = tk.Button(window, text="View Diary Entries", command=view_diary_entries)
view_diary_button.pack()

# Start the GUI main loop
window.mainloop()