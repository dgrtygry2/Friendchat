import tkinter as tk
from tkinter import messagebox
import subprocess
import os
import time
from pywinauto import Application


class SetupWizard:
    def __init__(self, master):
        self.master = master
        self.master.title("Setup Wizard")
        self.current_step = 0

        self.steps = [
            "Welcome to Friendchat! Press next to continue.",
            "Please NOTE this is BSD clause 3 software! No selling this as proprietary software. With that being said, That's it! Enjoy Friendchat!"
        ]

        self.label = tk.Label(self.master, text=self.steps[self.current_step], wraplength=300)
        self.label.pack(pady=20)

        self.next_button = tk.Button(self.master, text="Next", command=self.next_step)
        self.next_button.pack(side=tk.RIGHT, padx=10)

        self.back_button = tk.Button(self.master, text="Back", command=self.previous_step)
        self.back_button.pack(side=tk.RIGHT, padx=10)

        self.finish_button = tk.Button(self.master, text="Finish", command=self.finish)
        self.finish_button.pack(side=tk.RIGHT, padx=10)

        self.update_buttons()

    def next_step(self):
        if self.current_step < len(self.steps) - 1:
            self.current_step += 1
            self.label.config(text=self.steps[self.current_step])
            self.update_buttons()

    def previous_step(self):
        if self.current_step > 0:
            self.current_step -= 1
            self.label.config(text=self.steps[self.current_step])
            self.update_buttons()

    def finish(self):
        # Launch chatgui.exe
        try:
            subprocess.Popen(["chatgui.exe"])
            self.open_configuration_tool()
        except FileNotFoundError:
            messagebox.showerror("Error", "chatgui.exe not found.")

    def open_configuration_tool(self):
        self.config_window = tk.Toplevel(self.master)
        self.config_window.title("Configuration Tool")

        self.regenerate_button = tk.Button(self.config_window, text="Regenerate Response", command=self.regenerate_response)
        self.regenerate_button.pack(pady=20)

        # Hide the main window until the configuration tool is closed
        self.master.withdraw()
        self.config_window.protocol("WM_DELETE_WINDOW", self.on_config_close)

    def regenerate_response(self):
        # Wait for chatgui.exe to be ready for interaction
        time.sleep(1)

        # Use pywinauto to find the chatgui.exe window and clear the last response
        try:
            app = Application().connect(title="Chatbot")  # Make sure this matches your chat window title
            chat_window = app.window(title="Chatbot")

            # Simulate hiding the last message by clearing the chat entry
            chat_window.child_window(control_type="Edit").set_edit_text("")  # Clear the input box
            chat_window.child_window(title="Send", control_type="Button").click()  # Send an empty message

            # Notify the user
            messagebox.showinfo("Regenerate Response", "Last response hidden. A new response will be generated.")
        except Exception as e:
            messagebox.showerror("Error", f"Could not connect to chatgui.exe: {e}")

    def on_config_close(self):
        # Show the main window again when the configuration tool is closed
        self.master.deiconify()
        self.config_window.destroy()

    def update_buttons(self):
        self.back_button['state'] = tk.NORMAL if self.current_step > 0 else tk.DISABLED
        self.next_button['state'] = tk.NORMAL if self.current_step < len(self.steps) - 1 else tk.DISABLED
        self.finish_button['state'] = tk.NORMAL if self.current_step == len(self.steps) - 1 else tk.DISABLED


if __name__ == "__main__":
    root = tk.Tk()
    app = SetupWizard(root)
    root.mainloop()